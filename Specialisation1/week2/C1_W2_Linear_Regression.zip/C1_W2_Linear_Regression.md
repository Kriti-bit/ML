# Practice Lab: Linear Regression

Welcome to your first practice lab! In this lab, you will implement linear regression with one variable to predict profits for a restaurant franchise.


# Outline
- [ 1 - Packages ](#1)
- [ 2 - Linear regression with one variable ](#2)
  - [ 2.1 Problem Statement](#2.1)
  - [ 2.2  Dataset](#2.2)
  - [ 2.3 Refresher on linear regression](#2.3)
  - [ 2.4  Compute Cost](#2.4)
    - [ Exercise 1](#ex01)
  - [ 2.5 Gradient descent ](#2.5)
    - [ Exercise 2](#ex02)
  - [ 2.6 Learning parameters using batch gradient descent ](#2.6)


<a name="1"></a>
## 1 - Packages 

First, let's run the cell below to import all the packages that you will need during this assignment.
- [numpy](www.numpy.org) is the fundamental package for working with matrices in Python.
- [matplotlib](http://matplotlib.org) is a famous library to plot graphs in Python.
- ``utils.py`` contains helper functions for this assignment. You do not need to modify code in this file.



```python
import numpy as np
import matplotlib.pyplot as plt
from utils import *
import copy
import math
%matplotlib inline
```

## 2 -  Problem Statement

Suppose you are the CEO of a restaurant franchise and are considering different cities for opening a new outlet.
- You would like to expand your business to cities that may give your restaurant higher profits.
- The chain already has restaurants in various cities and you have data for profits and populations from the cities.
- You also have data on cities that are candidates for a new restaurant. 
    - For these cities, you have the city population.
    
Can you use the data to help you identify which cities may potentially give your business higher profits?

## 3 - Dataset

You will start by loading the dataset for this task. 
- The `load_data()` function shown below loads the data into variables `x_train` and `y_train`
  - `x_train` is the population of a city
  - `y_train` is the profit of a restaurant in that city. A negative value for profit indicates a loss.   
  - Both `X_train` and `y_train` are numpy arrays.


```python
# load the dataset
x_train, y_train = load_data()
```

#### View the variables
Before starting on any task, it is useful to get more familiar with your dataset.  
- A good place to start is to just print out each variable and see what it contains.

The code below prints the variable `x_train` and the type of the variable.


```python
# print x_train
print("Type of x_train:",type(x_train))
print("First five elements of x_train are:\n", x_train[:5]) 
```

    Type of x_train: <class 'numpy.ndarray'>
    First five elements of x_train are:
     [6.1101 5.5277 8.5186 7.0032 5.8598]


`x_train` is a numpy array that contains decimal values that are all greater than zero.
- These values represent the city population times 10,000
- For example, 6.1101 means that the population for that city is 61,101
  
Now, let's print `y_train`


```python
# print y_train
print("Type of y_train:",type(y_train))
print("First five elements of y_train are:\n", y_train[:5])  
```

    Type of y_train: <class 'numpy.ndarray'>
    First five elements of y_train are:
     [17.592   9.1302 13.662  11.854   6.8233]


Similarly, `y_train` is a numpy array that has decimal values, some negative, some positive.
- These represent your restaurant's average monthly profits in each city, in units of \$10,000.
  - For example, 17.592 represents \$175,920 in average monthly profits for that city.
  - -2.6807 represents -\$26,807 in average monthly loss for that city.

#### Check the dimensions of your variables

Another useful way to get familiar with your data is to view its dimensions.

Please print the shape of `x_train` and `y_train` and see how many training examples you have in your dataset.


```python
print ('The shape of x_train is:', x_train.shape)
print ('The shape of y_train is: ', y_train.shape)
print ('Number of training examples (m):', len(x_train))
```

    The shape of x_train is: (97,)
    The shape of y_train is:  (97,)
    Number of training examples (m): 97


The city population array has 97 data points, and the monthly average profits also has 97 data points. These are NumPy 1D arrays.

#### Visualize your data

It is often useful to understand the data by visualizing it. 
- For this dataset, you can use a scatter plot to visualize the data, since it has only two properties to plot (profit and population). 
- Many other problems that you will encounter in real life have more than two properties (for example, population, average household income, monthly profits, monthly sales).When you have more than two properties, you can still use a scatter plot to see the relationship between each pair of properties.



```python
# Create a scatter plot of the data. To change the markers to red "x",
# we used the 'marker' and 'c' parameters
plt.scatter(x_train, y_train, marker='x', c='r') 

# Set the title
plt.title("Profits vs. Population per city")
# Set the y-axis label
plt.ylabel('Profit in $10,000')
# Set the x-axis label
plt.xlabel('Population of City in 10,000s')
plt.show()
```


![png](output_14_0.png)


Your goal is to build a linear regression model to fit this data.
- With this model, you can then input a new city's population, and have the model estimate your restaurant's potential monthly profits for that city.

<a name="4"></a>
## 4 - Refresher on linear regression

In this practice lab, you will fit the linear regression parameters $(w,b)$ to your dataset.
- The model function for linear regression, which is a function that maps from `x` (city population) to `y` (your restaurant's monthly profit for that city) is represented as 
    $$f_{w,b}(x) = wx + b$$
    

- To train a linear regression model, you want to find the best $(w,b)$ parameters that fit your dataset.  

    - To compare how one choice of $(w,b)$ is better or worse than another choice, you can evaluate it with a cost function $J(w,b)$
      - $J$ is a function of $(w,b)$. That is, the value of the cost $J(w,b)$ depends on the value of $(w,b)$.
  
    - The choice of $(w,b)$ that fits your data the best is the one that has the smallest cost $J(w,b)$.


- To find the values $(w,b)$ that gets the smallest possible cost $J(w,b)$, you can use a method called **gradient descent**. 
  - With each step of gradient descent, your parameters $(w,b)$ come closer to the optimal values that will achieve the lowest cost $J(w,b)$.
  

- The trained linear regression model can then take the input feature $x$ (city population) and output a prediction $f_{w,b}(x)$ (predicted monthly profit for a restaurant in that city).

<a name="5"></a>
## 5 - Compute Cost

Gradient descent involves repeated steps to adjust the value of your parameter $(w,b)$ to gradually get a smaller and smaller cost $J(w,b)$.
- At each step of gradient descent, it will be helpful for you to monitor your progress by computing the cost $J(w,b)$ as $(w,b)$ gets updated. 
- In this section, you will implement a function to calculate $J(w,b)$ so that you can check the progress of your gradient descent implementation.

#### Cost function
As you may recall from the lecture, for one variable, the cost function for linear regression $J(w,b)$ is defined as

$$J(w,b) = \frac{1}{2m} \sum\limits_{i = 0}^{m-1} (f_{w,b}(x^{(i)}) - y^{(i)})^2$$ 

- You can think of $f_{w,b}(x^{(i)})$ as the model's prediction of your restaurant's profit, as opposed to $y^{(i)}$, which is the actual profit that is recorded in the data.
- $m$ is the number of training examples in the dataset

#### Model prediction

- For linear regression with one variable, the prediction of the model $f_{w,b}$ for an example $x^{(i)}$ is representented as:

$$ f_{w,b}(x^{(i)}) = wx^{(i)} + b$$

This is the equation for a line, with an intercept $b$ and a slope $w$

#### Implementation

Please complete the `compute_cost()` function below to compute the cost $J(w,b)$.

<a name="ex01"></a>
### Exercise 1

Complete the `compute_cost` below to:

* Iterate over the training examples, and for each example, compute:
    * The prediction of the model for that example 
    $$
    f_{wb}(x^{(i)}) =  wx^{(i)} + b 
    $$
   
    * The cost for that example  $$cost^{(i)} =  (f_{wb} - y^{(i)})^2$$
    

* Return the total cost over all examples
$$J(\mathbf{w},b) = \frac{1}{2m} \sum\limits_{i = 0}^{m-1} cost^{(i)}$$
  * Here, $m$ is the number of training examples and $\sum$ is the summation operator

If you get stuck, you can check out the hints presented after the cell below to help you with the implementation.


```python
# UNQ_C1
# GRADED FUNCTION: compute_cost

def compute_cost(x, y, w, b): 
    """
    Computes the cost function for linear regression.
    
    Args:
        x (ndarray): Shape (m,) Input to the model (Population of cities) 
        y (ndarray): Shape (m,) Label (Actual profits for the cities)
        w, b (scalar): Parameters of the model
    
    Returns
        total_cost (float): The cost of using w,b as the parameters for linear regression
               to fit the data points in x and y
    """
    # number of training examples
    m = x.shape[0] 
    
    # You need to return this variable correctly
    total_cost = 0
    y_pred = 0
    cost = 0
    
    ### START CODE HERE ### 
    for i in range(0,m):
        y_pred = w*x[i] + b
        cost = (y_pred - y[i])**2
        total_cost = total_cost + cost
    
    total_cost = total_cost/(2*m)
    print(total_cost)
    
    ### END CODE HERE ### 

    return total_cost
```

<details>
  <summary><font size="3" color="darkgreen"><b>Click for hints</b></font></summary>
    
    
   * You can represent a summation operator eg: $h = \sum\limits_{i = 0}^{m-1} 2i$ in code as follows:
     ```python 
    h = 0
    for i in range(m):
        h = h + 2*i
    ```
  
   * In this case, you can iterate over all the examples in `x` using a for loop and add the `cost` from each iteration to a variable (`cost_sum`) initialized outside the loop.

   * Then, you can return the `total_cost` as `cost_sum` divided by `2m`.
     
    <details>
          <summary><font size="2" color="darkblue"><b> Click for more hints</b></font></summary>
        
    * Here's how you can structure the overall implementation for this function
    ```python 
    def compute_cost(x, y, w, b):
        # number of training examples
        m = x.shape[0] 
    
        # You need to return this variable correctly
        total_cost = 0
    
        ### START CODE HERE ###  
        # Variable to keep track of sum of cost from each example
        cost_sum = 0
    
        # Loop over training examples
        for i in range(m):
            # Your code here to get the prediction f_wb for the ith example
            f_wb = 
            # Your code here to get the cost associated with the ith example
            cost = 
        
            # Add to sum of cost for each example
            cost_sum = cost_sum + cost 

        # Get the total cost as the sum divided by (2*m)
        total_cost = (1 / (2 * m)) * cost_sum
        ### END CODE HERE ### 

        return total_cost
    ```
    
    If you're still stuck, you can check the hints presented below to figure out how to calculate `f_wb` and `cost`.
    
    <details>
          <summary><font size="2" color="darkblue"><b>Hint to calculate f_wb</b></font></summary>
           &emsp; &emsp; For scalars $a$, $b$ and $c$ (<code>x[i]</code>, <code>w</code> and <code>b</code> are all scalars), you can calculate the equation $h = ab + c$ in code as <code>h = a * b + c</code>
          <details>
              <summary><font size="2" color="blue"><b>&emsp; &emsp; More hints to calculate f</b></font></summary>
               &emsp; &emsp; You can compute f_wb as <code>f_wb = w * x[i] + b </code>
           </details>
    </details>

     <details>
          <summary><font size="2" color="darkblue"><b>Hint to calculate cost</b></font></summary>
          &emsp; &emsp; You can calculate the square of a variable z as z**2
          <details>
              <summary><font size="2" color="blue"><b>&emsp; &emsp; More hints to calculate cost</b></font></summary>
              &emsp; &emsp; You can compute cost as <code>cost = (f_wb - y[i]) ** 2</code>
          </details>
    </details>
        
    </details>

</details>

    


You can check if your implementation was correct by running the following test code:


```python
# Compute cost with some initial values for paramaters w, b
initial_w = 2
initial_b = 1

cost = compute_cost(x_train, y_train, initial_w, initial_b)
print(type(cost))
print(f'Cost at initial w: {cost:.3f}')

# Public tests
from public_tests import *
compute_cost_test(compute_cost)
```

    75.20338497891959
    <class 'numpy.float64'>
    Cost at initial w: 75.203
    0.0
    2.0
    15.325
    10.725
    4.525
    [92mAll tests passed!


**Expected Output**:
<table>
  <tr>
    <td> <b>Cost at initial w:<b> 75.203 </td> 
  </tr>
</table>

<a name="6"></a>
## 6 - Gradient descent 

In this section, you will implement the gradient for parameters $w, b$ for linear regression. 

As described in the lecture videos, the gradient descent algorithm is:

$$\begin{align*}& \text{repeat until convergence:} \; \lbrace \newline \; & \phantom {0000} b := b -  \alpha \frac{\partial J(w,b)}{\partial b} \newline       \; & \phantom {0000} w := w -  \alpha \frac{\partial J(w,b)}{\partial w} \tag{1}  \; & 
\newline & \rbrace\end{align*}$$

where, parameters $w, b$ are both updated simultaniously and where  
$$
\frac{\partial J(w,b)}{\partial b}  = \frac{1}{m} \sum\limits_{i = 0}^{m-1} (f_{w,b}(x^{(i)}) - y^{(i)}) \tag{2}
$$
$$
\frac{\partial J(w,b)}{\partial w}  = \frac{1}{m} \sum\limits_{i = 0}^{m-1} (f_{w,b}(x^{(i)}) -y^{(i)})x^{(i)} \tag{3}
$$
* m is the number of training examples in the dataset

    
*  $f_{w,b}(x^{(i)})$ is the model's prediction, while $y^{(i)}$, is the target value


You will implement a function called `compute_gradient` which calculates $\frac{\partial J(w)}{\partial w}$, $\frac{\partial J(w)}{\partial b}$ 

<a name="ex02"></a>
### Exercise 2

Please complete the `compute_gradient` function to:

* Iterate over the training examples, and for each example, compute:
    * The prediction of the model for that example 
    $$
    f_{wb}(x^{(i)}) =  wx^{(i)} + b 
    $$
   
    * The gradient for the parameters $w, b$ from that example 
        $$
        \frac{\partial J(w,b)}{\partial b}^{(i)}  =  (f_{w,b}(x^{(i)}) - y^{(i)}) 
        $$
        $$
        \frac{\partial J(w,b)}{\partial w}^{(i)}  =  (f_{w,b}(x^{(i)}) -y^{(i)})x^{(i)} 
        $$
    

* Return the total gradient update from all the examples
    $$
    \frac{\partial J(w,b)}{\partial b}  = \frac{1}{m} \sum\limits_{i = 0}^{m-1} \frac{\partial J(w,b)}{\partial b}^{(i)}
    $$
    
    $$
    \frac{\partial J(w,b)}{\partial w}  = \frac{1}{m} \sum\limits_{i = 0}^{m-1} \frac{\partial J(w,b)}{\partial w}^{(i)} 
    $$
  * Here, $m$ is the number of training examples and $\sum$ is the summation operator

If you get stuck, you can check out the hints presented after the cell below to help you with the implementation.


```python
# UNQ_C2
# GRADED FUNCTION: compute_gradient
def compute_gradient(x, y, w, b): 
    """
    Computes the gradient for linear regression 
    Args:
      x (ndarray): Shape (m,) Input to the model (Population of cities) 
      y (ndarray): Shape (m,) Label (Actual profits for the cities)
      w, b (scalar): Parameters of the model  
    Returns
      dj_dw (scalar): The gradient of the cost w.r.t. the parameters w
      dj_db (scalar): The gradient of the cost w.r.t. the parameter b     
     """
    
    # Number of training examples
    m = x.shape[0]
    
    # You need to return the following variables correctly
    dj_dw = 0
    dj_db = 0
    
    ### START CODE HERE ### 
    for i in range(m):
        f = w*x[i] + b
        dj_db_temp = f - y[i]
        dj_dw_temp = dj_db_temp*x[i] 
        dj_dw += dj_dw_temp
        dj_db += dj_db_temp
        
    dj_dw = dj_dw/m
    dj_db = dj_db/m
    ### END CODE HERE ### 
        
    return dj_dw, dj_db
```

<details>
  <summary><font size="3" color="darkgreen"><b>Click for hints</b></font></summary>
       
    * You can represent a summation operator eg: $h = \sum\limits_{i = 0}^{m-1} 2i$ in code as follows:
     ```python 
    h = 0
    for i in range(m):
        h = h + 2*i
    ```
    
    * In this case, you can iterate over all the examples in `x` using a for loop and for each example, keep adding the gradient from that example to the variables `dj_dw` and `dj_db` which are initialized outside the loop. 

   * Then, you can return `dj_dw` and `dj_db` both divided by `m`.    
    <details>
          <summary><font size="2" color="darkblue"><b> Click for more hints</b></font></summary>
        
    * Here's how you can structure the overall implementation for this function
    ```python 
    def compute_gradient(x, y, w, b): 
        """
        Computes the gradient for linear regression 
        Args:
          x (ndarray): Shape (m,) Input to the model (Population of cities) 
          y (ndarray): Shape (m,) Label (Actual profits for the cities)
          w, b (scalar): Parameters of the model  
        Returns
          dj_dw (scalar): The gradient of the cost w.r.t. the parameters w
          dj_db (scalar): The gradient of the cost w.r.t. the parameter b     
         """
    
        # Number of training examples
        m = x.shape[0]
    
        # You need to return the following variables correctly
        dj_dw = 0
        dj_db = 0
    
        ### START CODE HERE ### 
        # Loop over examples
        for i in range(m):  
            # Your code here to get prediction f_wb for the ith example
            f_wb = 
            
            # Your code here to get the gradient for w from the ith example 
            dj_dw_i = 
        
            # Your code here to get the gradient for b from the ith example 
            dj_db_i = 
     
            # Update dj_db : In Python, a += 1  is the same as a = a + 1
            dj_db += dj_db_i
        
            # Update dj_dw
            dj_dw += dj_dw_i
    
        # Divide both dj_dw and dj_db by m
        dj_dw = dj_dw / m
        dj_db = dj_db / m
        ### END CODE HERE ### 
        
        return dj_dw, dj_db
    ```
    
    If you're still stuck, you can check the hints presented below to figure out how to calculate `f_wb` and `cost`.
    
    <details>
          <summary><font size="2" color="darkblue"><b>Hint to calculate f_wb</b></font></summary>
           &emsp; &emsp; You did this in the previous exercise! For scalars $a$, $b$ and $c$ (<code>x[i]</code>, <code>w</code> and <code>b</code> are all scalars), you can calculate the equation $h = ab + c$ in code as <code>h = a * b + c</code>
          <details>
              <summary><font size="2" color="blue"><b>&emsp; &emsp; More hints to calculate f</b></font></summary>
               &emsp; &emsp; You can compute f_wb as <code>f_wb = w * x[i] + b </code>
           </details>
    </details>
        
    <details>
          <summary><font size="2" color="darkblue"><b>Hint to calculate dj_dw_i</b></font></summary>
           &emsp; &emsp; For scalars $a$, $b$ and $c$ (<code>f_wb</code>, <code>y[i]</code> and <code>x[i]</code> are all scalars), you can calculate the equation $h = (a - b)c$ in code as <code>h = (a-b)*c</code>
          <details>
              <summary><font size="2" color="blue"><b>&emsp; &emsp; More hints to calculate f</b></font></summary>
               &emsp; &emsp; You can compute dj_dw_i as <code>dj_dw_i = (f_wb - y[i]) * x[i] </code>
           </details>
    </details>
        
    <details>
          <summary><font size="2" color="darkblue"><b>Hint to calculate dj_db_i</b></font></summary>
             &emsp; &emsp; You can compute dj_db_i as <code> dj_db_i = f_wb - y[i] </code>
    </details>
        
    </details>

</details>

    


Run the cells below to check your implementation of the `compute_gradient` function with two different initializations of the parameters $w$,$b$.


```python
# Compute and display gradient with w initialized to zeroes
initial_w = 0
initial_b = 0

tmp_dj_dw, tmp_dj_db = compute_gradient(x_train, y_train, initial_w, initial_b)
print('Gradient at initial w, b (zeros):', tmp_dj_dw, tmp_dj_db)

compute_gradient_test(compute_gradient)
```

    Gradient at initial w, b (zeros): -65.32884974555672 -5.83913505154639
    Using X with shape (4, 1)
    [92mAll tests passed!


Now let's run the gradient descent algorithm implemented above on our dataset.

**Expected Output**:
<table>
  <tr>
    <td> <b>Gradient at initial , b (zeros)<b></td>
    <td> -65.32884975 -5.83913505154639</td> 
  </tr>
</table>


```python
# Compute and display cost and gradient with non-zero w
test_w = 0.2
test_b = 0.2
tmp_dj_dw, tmp_dj_db = compute_gradient(x_train, y_train, test_w, test_b)

print('Gradient at test w, b:', tmp_dj_dw, tmp_dj_db)
```

    Gradient at test w, b: -47.41610118114435 -4.007175051546391


**Expected Output**:
<table>
  <tr>
    <td> <b>Gradient at test w<b></td>
    <td> -47.41610118 -4.007175051546391</td> 
  </tr>
</table>

<a name="2.6"></a>
### 2.6 Learning parameters using batch gradient descent 

You will now find the optimal parameters of a linear regression model by using batch gradient descent. Recall batch refers to running all the examples in one iteration.
- You don't need to implement anything for this part. Simply run the cells below. 

- A good way to verify that gradient descent is working correctly is to look
at the value of $J(w,b)$ and check that it is decreasing with each step. 

- Assuming you have implemented the gradient and computed the cost correctly and you have an appropriate value for the learning rate alpha, $J(w,b)$ should never increase and should converge to a steady value by the end of the algorithm.


```python
def gradient_descent(x, y, w_in, b_in, cost_function, gradient_function, alpha, num_iters): 
    """
    Performs batch gradient descent to learn theta. Updates theta by taking 
    num_iters gradient steps with learning rate alpha
    
    Args:
      x :    (ndarray): Shape (m,)
      y :    (ndarray): Shape (m,)
      w_in, b_in : (scalar) Initial values of parameters of the model
      cost_function: function to compute cost
      gradient_function: function to compute the gradient
      alpha : (float) Learning rate
      num_iters : (int) number of iterations to run gradient descent
    Returns
      w : (ndarray): Shape (1,) Updated values of parameters of the model after
          running gradient descent
      b : (scalar)                Updated value of parameter of the model after
          running gradient descent
    """
    
    # number of training examples
    m = len(x)
    
    # An array to store cost J and w's at each iteration — primarily for graphing later
    J_history = []
    w_history = []
    w = copy.deepcopy(w_in)  #avoid modifying global w within function
    b = b_in
    
    for i in range(num_iters):

        # Calculate the gradient and update the parameters
        dj_dw, dj_db = gradient_function(x, y, w, b )  

        # Update Parameters using w, b, alpha and gradient
        w = w - alpha * dj_dw               
        b = b - alpha * dj_db               

        # Save cost J at each iteration
        if i<100000:      # prevent resource exhaustion 
            cost =  cost_function(x, y, w, b)
            J_history.append(cost)

        # Print cost every at intervals 10 times or as many iterations if < 10
        if i% math.ceil(num_iters/10) == 0:
            w_history.append(w)
            print(f"Iteration {i:4}: Cost {float(J_history[-1]):8.2f}   ")
        
    return w, b, J_history, w_history #return w and J,w history for graphing
```

Now let's run the gradient descent algorithm above to learn the parameters for our dataset.


```python
# initialize fitting parameters. Recall that the shape of w is (n,)
initial_w = 0.
initial_b = 0.

# some gradient descent settings
iterations = 1500
alpha = 0.01

w,b,_,_ = gradient_descent(x_train ,y_train, initial_w, initial_b, 
                     compute_cost, compute_gradient, alpha, iterations)
print("w,b found by gradient descent:", w, b)
```

    6.737190464870008
    Iteration    0: Cost     6.74   
    5.931593568604957
    5.901154707081387
    5.89522858644422
    5.890094943117333
    5.885004158443646
    5.879932480491416
    5.874879094762575
    5.8698439118063845
    5.8648268653129305
    5.8598278899321805
    5.85484692057229
    5.849883892376585
    5.844938740722036
    5.840011401218365
    5.835101809707228
    5.830209902261389
    5.825335615183866
    5.820478885007098
    5.8156396484921515
    5.81081784262787
    5.806013404630042
    5.801226271940627
    5.796456382226899
    5.791703673380652
    5.786968083517397
    5.782249550975539
    5.777548014315598
    5.772863412319381
    5.768195683989212
    5.76354476854712
    5.758910605434049
    5.754293134309077
    5.7496922950486296
    5.745108027745686
    5.740540272709014
    5.735988970462384
    5.7314540617437935
    5.7269354875047025
    5.722433188909259
    5.717947107333528
    5.713477184364749
    5.709023361800547
    5.704585581648199
    5.700163786123851
    5.695757917651815
    5.69136791886375
    5.6869937325979825
    5.6826353018987055
    5.6782925700152935
    5.673965480401505
    5.669653976714796
    5.665358002815552
    5.661077502766383
    5.656812420831358
    5.6525627014753335
    5.648328289363183
    5.6441091293590935
    5.639905166525854
    5.635716346124134
    5.6315426136117726
    5.627383914643053
    5.623240195068026
    5.6191114009317795
    5.6149974784737395
    5.610898374126983
    5.606814034517532
    5.6027444064636525
    5.598689436975159
    5.594649073252758
    5.590623262687323
    5.586611952859217
    5.582615091537621
    5.578632626679853
    5.574664506430677
    5.570710679121647
    5.566771093270404
    5.562845697580047
    5.558934440938444
    5.555037272417541
    5.551154141272755
    5.547284996942256
    5.543429789046351
    5.539588467386808
    5.535760981946204
    5.531947282887273
    5.528147320552271
    5.524361045462307
    5.520588408316713
    5.516829359992401
    5.513083851543223
    5.509351834199334
    5.5056332593665385
    5.501928078625699
    5.498236243732062
    5.494557706614665
    5.490892419375678
    5.487240334289807
    5.483601403803651
    5.479975580535111
    5.476362817272741
    5.472763066975153
    5.469176282770398
    5.465602417955358
    5.462041425995138
    5.4584932605224585
    5.454957875337047
    5.451435224405054
    5.447925261858425
    5.444427941994334
    5.440943219274568
    5.437471048324931
    5.434011383934687
    5.430564181055921
    5.4271293948029875
    5.423706980451917
    5.420296893439838
    5.416899089364381
    5.413513523983123
    5.410140153212986
    5.4067789331296945
    5.403429819967165
    5.400092770116975
    5.3967677401277685
    5.393454686704697
    5.390153566708864
    5.386864337156749
    5.383586955219662
    5.380321378223177
    5.377067563646583
    5.373825469122315
    5.370595052435429
    5.367376271523024
    5.364169084473711
    5.360973449527068
    5.3577893250730835
    5.354616669651634
    5.351455441951913
    5.348305600811943
    5.345167105217981
    5.34203991430403
    5.338923987351284
    5.335819283787603
    5.332725763186986
    5.329643385269055
    5.326572109898499
    5.323511897084589
    5.320462706980629
    5.317424499883462
    5.314397236232924
    5.311380876611357
    Iteration  150: Cost     5.31   
    5.308375381743072
    5.305380712493862
    5.302396829870465
    5.2994236950200815
    5.29646126922985
    5.2935095139263595
    5.290568390675126
    5.287637861180119
    5.2847178872832306
    5.281808430963812
    5.278909454338152
    5.276020919659002
    5.27314278931507
    5.270275025830545
    5.267417591864591
    5.264570450210886
    5.26173356379711
    5.2589068956844836
    5.256090409067275
    5.253284067272323
    5.250487833758565
    5.247701672116554
    5.244925546067996
    5.242159419465253
    5.2394032562909025
    5.236657020657249
    5.233920676805869
    5.231194189107128
    5.228477522059737
    5.225770640290267
    5.223073508552727
    5.220386091728056
    5.217708354823696
    5.215040262973137
    5.212381781435449
    5.209732875594843
    5.207093510960208
    5.204463653164676
    5.201843267965148
    5.199232321241894
    5.196630778998063
    5.194038607359261
    5.19145577257311
    5.188882241008802
    5.1863179791566765
    5.183762953627759
    5.181217131153349
    5.178680478584577
    5.176152962891968
    5.173634551165023
    5.1711252106117795
    5.168624908558405
    5.166133612448731
    5.163651289843876
    5.161177908421788
    5.158713435976852
    5.156257840419432
    5.153811089775505
    5.151373152186197
    5.148943995907394
    5.146523589309324
    5.144111900876141
    5.141708899205514
    5.139314553008235
    5.136928831107778
    5.134551702439931
    5.1321831360523635
    5.129823101104237
    5.127471566865795
    5.125128502717983
    5.1227938781520095
    5.120467662768993
    5.118149826279544
    5.115840338503369
    5.113539169368884
    5.111246288912826
    5.108961667279849
    5.106685274722152
    5.104417081599076
    5.102157058376735
    5.099905175627619
    5.097661404030209
    5.09542571436861
    5.0931980775321515
    5.090978464515023
    5.088766846415888
    5.086563194437519
    5.0843674798863985
    5.082179674172385
    5.079999748808298
    5.077827675409569
    5.075663425693872
    5.073506971480756
    5.071358284691266
    5.069217337347599
    5.067084101572703
    5.06495854958997
    5.062840653722809
    5.0607303863943445
    5.058627720127012
    5.056532627542232
    5.054445081360034
    5.052365054398718
    5.050292519574479
    5.048227449901074
    5.046169818489458
    5.044119598547441
    5.042076763379342
    5.040041286385625
    5.038013141062577
    5.03599230100194
    5.033978739890577
    5.031972431510143
    5.029973349736707
    5.0279814685404585
    5.025996761985323
    5.0240192042286695
    5.022048769520929
    5.020085432205297
    5.01812916671737
    5.016179947584836
    5.014237749427131
    5.012302546955105
    5.010374314970706
    5.00845302836664
    5.006538662126046
    5.004631191322177
    5.002730591118059
    5.0008368367662
    4.998949903608226
    4.997069767074595
    4.995196402684253
    4.993329786044339
    4.991469892849847
    4.989616698883302
    4.987770180014482
    4.985930312200063
    4.984097071483333
    4.982270433993872
    4.9804503759472345
    4.978636873644651
    4.976829903472698
    4.97502944190303
    4.973235465492033
    4.971447950880541
    4.96966687479352
    4.967892214039784
    4.966123945511667
    4.964362046184745
    4.962606493117519
    Iteration  300: Cost     4.96   
    4.960857263451132
    4.959114334409054
    4.957377683296803
    4.955647287501641
    4.953923124492269
    4.952205171818561
    4.950493407111239
    4.948787808081608
    4.947088352521254
    4.945395018301758
    4.943707783374399
    4.942026625769874
    4.94035152359803
    4.938682455047537
    4.937019398385643
    4.93536233195787
    4.933711234187741
    4.9320660835764984
    4.930426858702816
    4.928793538222535
    4.927166100868364
    4.925544525449623
    4.923928790851962
    4.922318876037082
    4.920714760042451
    4.9191164219810695
    4.917523841041141
    4.915936996485851
    4.914355867653075
    4.912780433955112
    4.91121067487841
    4.909646569983313
    4.908088098903787
    4.90653524134715
    4.904987977093813
    4.903446285997033
    4.901910147982609
    4.900379543048668
    4.898854451265367
    4.897334852774656
    4.8958207277900145
    4.894312056596191
    4.892808819548946
    4.8913109970747914
    4.889818569670748
    4.888331517904089
    4.88684982241208
    4.8853734639017246
    4.883902423149521
    4.88243668100122
    4.880976218371549
    4.879521016243988
    4.878071055670512
    4.876626317771341
    4.875186783734711
    4.87375243481661
    4.872323252340536
    4.870899217697262
    4.869480312344593
    4.868066517807121
    4.866657815675987
    4.865254187608632
    4.863855615328573
    4.862462080625158
    4.861073565353325
    4.859690051433372
    4.858311520850716
    4.856937955655665
    4.855569337963179
    4.8542056499526405
    4.852846873867618
    4.851492992015638
    4.850143986767961
    4.8487998405593355
    4.8474605358877865
    4.84612605531437
    4.844796381462971
    4.843471497020046
    4.842151384734427
    4.8408360274170805
    4.839525407940882
    4.838219509240405
    4.8369183143116805
    4.835621806212
    4.834329968059677
    4.833042783033826
    4.831760234374152
    4.830482305380745
    4.829208979413816
    4.827940239893543
    4.826676070299798
    4.825416454171979
    4.824161375108761
    4.822910816767899
    4.821664762866013
    4.820423197178368
    4.819186103538688
    4.817953465838903
    4.816725268028978
    4.815501494116685
    4.814282128167403
    4.813067154303901
    4.8118565567061395
    4.810650319611067
    4.809448427312395
    4.808250864160423
    4.807057614561819
    4.805868662979406
    4.8046839939319765
    4.80350359199409
    4.802327441795865
    4.80115552802278
    4.799987835415476
    4.798824348769554
    4.79766505293539
    4.796509932817917
    4.795358973376449
    4.794212159624466
    4.793069476629437
    4.79193090951261
    4.790796443448837
    4.789666063666357
    4.7885397554466165
    4.787417504124084
    4.786299295086056
    4.785185113772449
    4.784074945675636
    4.78296877634024
    4.781866591362952
    4.780768376392355
    4.779674117128694
    4.778583799323757
    4.7774974087806354
    4.776414931353553
    4.775336352947691
    4.7742616595190075
    4.773190837074033
    4.772123871669706
    4.771060749413198
    4.770001456461704
    4.768945979022286
    4.767894303351698
    4.766846415756183
    4.765802302591317
    4.764761950261813
    4.763725345221363
    4.762692473972447
    4.761663323066167
    4.7606378791020525
    4.7596161287279255
    Iteration  450: Cost     4.76   
    4.758598058639682
    4.757583655581143
    4.756572906343875
    4.755565797767039
    4.754562316737174
    4.753562450188065
    4.752566185100569
    4.751573508502424
    4.750584407468102
    4.749598869118619
    4.7486168806214
    4.747638429190076
    4.746663502084347
    4.745692086609787
    4.744724170117707
    4.7437597400049745
    4.74279878371385
    4.741841288731832
    4.7408872425914845
    4.739936632870271
    4.738989447190422
    4.738045673218729
    4.737105298666416
    4.736168311288971
    4.7352346988859875
    4.734304449301007
    4.73337755042134
    4.732453990177953
    4.731533756545258
    4.730616837541011
    4.7297032212260985
    4.72879289570443
    4.72788584912275
    4.726982069670518
    4.726081545579716
    4.725184265124724
    4.724290216622141
    4.723399388430679
    4.7225117689509455
    4.721627346625359
    4.72074610993795
    4.7198680474142325
    4.718993147621053
    4.7181213991664395
    4.71725279069945
    4.716387310910037
    4.7155249485288735
    4.714665692327246
    4.713809531116865
    4.712956453749759
    4.712106449118097
    4.711259506154068
    4.710415613829714
    4.709574761156817
    4.708736937186723
    4.707902131010218
    4.70707033175738
    4.706241528597455
    4.705415710738677
    4.704592867428175
    4.703772987951789
    4.702956061633963
    4.702142077837589
    4.701331025963876
    4.700522895452207
    4.699717675780004
    4.698915356462592
    4.6981159270530615
    4.6973193771421275
    4.696525696358009
    4.695734874366266
    4.694946900869704
    4.694161765608201
    4.6933794583586
    4.692599968934568
    4.691823287186456
    4.69104940300118
    4.690278306302077
    4.689509987048791
    4.68874443523711
    4.687981640898881
    4.687221594101834
    4.6864642849494915
    4.685709703581009
    4.6849578401710685
    4.684208684929743
    4.683462228102363
    4.682718459969403
    4.6819773708463295
    4.681238951083514
    4.680503191066068
    4.6797700812137455
    4.6790396119808015
    4.678311773855884
    4.677586557361886
    4.67686395305585
    4.676143951528825
    4.675426543405747
    4.674711719345328
    4.673999470039923
    4.673289786215413
    4.672582658631085
    4.671878078079504
    4.671176035386411
    4.670476521410587
    4.669779527043732
    4.669085043210367
    4.668393060867687
    4.667703571005475
    4.667016564645956
    4.666332032843699
    4.665649966685487
    4.664970357290217
    4.664293195808769
    4.663618473423901
    4.662946181350124
    4.6622763108336
    4.661608853152019
    4.660943799614486
    4.660281141561419
    4.659620870364415
    4.6589629774261585
    4.658307454180304
    4.657654292091348
    4.657003482654544
    4.656355017395771
    4.655708887871438
    4.655065085668368
    4.654423602403678
    4.653784429724685
    4.6531475593088025
    4.652512982863399
    4.651880692125732
    4.651250678862817
    4.650622934871315
    4.649997451977443
    4.64937422203686
    4.648753236934553
    4.648134488584752
    4.6475179689308
    4.646903669945063
    4.646291583628818
    4.645681702012166
    4.645074017153896
    4.644468521141422
    4.643865206090639
    4.643264064145854
    4.642665087479663
    4.6420682682928565
    4.6414735988143185
    Iteration  600: Cost     4.64   
    4.640881071300923
    4.640290678037439
    4.639702411336421
    4.6391162635381065
    4.638532227010339
    4.637950294148439
    4.637370457375127
    4.636792709140406
    4.636217041921486
    4.635643448222669
    4.635071920575257
    4.634502451537444
    4.633935033694242
    4.633369659657367
    4.632806322065147
    4.632245013582419
    4.631685726900461
    4.631128454736849
    4.630573189835416
    4.630019924966111
    4.629468652924938
    4.628919366533841
    4.6283720586406325
    4.627826722118865
    4.6272833498677794
    4.626741934812183
    4.626202469902376
    4.625664948114038
    4.625129362448163
    4.62459570593095
    4.6240639716137135
    4.623534152572802
    4.623006241909501
    4.622480232749946
    4.621956118245026
    4.621433891570306
    4.620913545925932
    4.620395074536541
    4.619878470651173
    4.619363727543186
    4.618850838510171
    4.6183397968738555
    4.617830595980022
    4.617323229198419
    4.6168176899226845
    4.61631397157025
    4.615812067582252
    4.615311971423452
    4.614813676582156
    4.6143171765701245
    4.613822464922478
    4.61332953519764
    4.612838380977224
    4.612348995865971
    4.611861373491644
    4.611375507504967
    4.6108913915795355
    4.610409019411731
    4.609928384720636
    4.609449481247961
    4.608972302757962
    4.608496843037342
    4.608023095895196
    4.60755105516292
    4.607080714694121
    4.606612068364546
    4.606145110072005
    4.605679833736285
    4.6052162332990765
    4.60475430272389
    4.604294035995975
    4.603835427122255
    4.603378470131233
    4.602923159072921
    4.602469488018765
    4.602017451061565
    4.601567042315396
    4.601118255915542
    4.600671086018401
    4.600225526801421
    4.599781572463033
    4.599339217222544
    4.598898455320108
    4.598459281016607
    4.598021688593604
    4.597585672353254
    4.597151226618243
    4.596718345731695
    4.596287024057118
    4.595857255978323
    4.5954290358993495
    4.5950023582443835
    4.594577217457711
    4.594153608003616
    4.593731524366331
    4.593310961049949
    4.592891912578359
    4.592474373495181
    4.592058338363686
    4.591643801766726
    4.591230758306667
    4.590819202605311
    4.5904091293038425
    4.590000533062744
    4.589593408561724
    4.589187750499663
    4.588783553594526
    4.5883808125833205
    4.587979522221998
    4.587579677285392
    4.58718127256718
    4.586784302879762
    4.586388763054257
    4.585994647940377
    4.585601952406394
    4.585210671339057
    4.584820799643549
    4.584432332243385
    4.584045264080383
    4.583659590114559
    4.583275305324111
    4.582892404705296
    4.582510883272416
    4.582130736057724
    4.581751958111355
    4.581374544501293
    4.580998490313271
    4.580623790650736
    4.580250440634761
    4.579878435403997
    4.579507770114605
    4.5791384399401975
    4.5787704400717635
    4.578403765717619
    4.5780384121033375
    4.577674374471691
    4.577311648082582
    4.576950228212994
    4.57659011015692
    4.57623128922531
    4.5758737607459805
    4.5755175200636025
    4.575162562539603
    4.574808883552121
    4.574456478495941
    4.57410534278244
    4.573755471839512
    4.573406861111527
    4.573059506059269
    4.572713402159868
    Iteration  750: Cost     4.57   
    4.572368544906732
    4.5720249298095235
    4.57168255239407
    4.571341408202299
    4.571001492792232
    4.570662801737848
    4.570325330629093
    4.569989075071802
    4.569654030687622
    4.569320193113978
    4.568987558004013
    4.568656121026516
    4.568325877865883
    4.567996824222056
    4.567668955810469
    4.567342268361973
    4.567016757622818
    4.566692419354561
    4.566369249334025
    4.5660472433532595
    4.565726397219449
    4.565406706754897
    4.56508816779695
    4.564770776197948
    4.564454527825171
    4.564139418560776
    4.563825444301775
    4.563512600959931
    4.5632008844617475
    4.562890290748408
    4.5625808157756955
    4.562272455513971
    4.561965205948124
    4.561659063077476
    4.561354022915784
    4.56105008149115
    4.560747234845988
    4.5604454790369635
    4.560144810134944
    4.559845224224966
    4.559546717406147
    4.559249285791658
    4.55895292550868
    4.558657632698342
    4.558363403515663
    4.558070234129523
    4.557778120722592
    4.557487059491293
    4.557197046645755
    4.556908078409752
    4.556620151020653
    4.5563332607293985
    4.556047403800418
    4.555762576511593
    4.555478775154231
    4.555195996032978
    4.554914235465802
    4.554633489783928
    4.554353755331797
    4.554075028467021
    4.553797305560327
    4.553520582995514
    4.553244857169412
    4.552970124491822
    4.552696381385484
    4.5524236242860185
    4.5521518496418825
    4.551881053914332
    4.551611233577363
    4.551342385117678
    4.551074505034633
    4.550807589840179
    4.5505416360588615
    4.550276640227711
    4.550012598896252
    4.549749508626435
    4.549487365992581
    4.549226167581371
    4.548965909991763
    4.548706589834976
    4.548448203734425
    4.548190748325696
    4.547934220256495
    4.547678616186597
    4.547423932787805
    4.5471701667439195
    4.546917314750678
    4.546665373515725
    4.546414339758558
    4.5461642102105015
    4.545914981614642
    4.545666650725799
    4.545419214310491
    4.545172669146868
    4.544927012024698
    4.544682239745305
    4.544438349121537
    4.5441953369777215
    4.543953200149627
    4.543711935484407
    4.543471539840591
    4.543232010088011
    4.542993343107777
    4.542755535792233
    4.542518585044915
    4.542282487780517
    4.542047240924835
    4.541812841414761
    4.541579286198187
    4.541346572234026
    4.541114696492134
    4.540883655953284
    4.540653447609125
    4.540424068462129
    4.540195515525589
    4.539967785823539
    4.539740876390731
    4.539514784272603
    4.539289506525236
    4.53906504021532
    4.538841382420098
    4.538618530227344
    4.538396480735328
    4.538175231052766
    4.537954778298799
    4.537735119602922
    4.5375162521049965
    4.537298172955166
    4.537080879313846
    4.536864368351685
    4.536648637249518
    4.536433683198327
    4.536219503399223
    4.536006095063397
    4.535793455412083
    4.53558158167652
    4.5353704710979255
    4.535160120927452
    4.534950528426154
    4.534741690864949
    4.534533605524582
    4.5343262696956135
    4.534119680678329
    4.533913835782765
    4.533708732328637
    4.5335043676453095
    4.533300739071781
    4.533097843956626
    4.53289567965796
    4.532694243543437
    Iteration  900: Cost     4.53   
    4.532493532990172
    4.532293545384733
    4.532094278123113
    4.5318957286106665
    4.53169789426211
    4.531500772501459
    4.531304360762016
    4.53110865648632
    4.530913657126132
    4.530719360142385
    4.530525763005162
    4.530332863193652
    4.5301406581961325
    4.5299491455099234
    4.529758322641358
    4.529568187105754
    4.529378736427377
    4.529189968139409
    4.529001879783918
    4.5288144689118335
    4.528627733082891
    4.5284416698656305
    4.52825627683734
    4.52807155158404
    4.527887491700443
    4.527704094789921
    4.527521358464492
    4.527339280344756
    4.527157858059903
    4.526977089247652
    4.526796971554226
    4.5266175026343385
    4.526438680151145
    4.526260501776217
    4.526082965189514
    4.525906068079347
    4.525729808142365
    4.525554183083503
    4.525379190615968
    4.525204828461203
    4.525031094348856
    4.524857986016757
    4.524685501210882
    4.524513637685319
    4.524342393202258
    4.524171765531945
    4.524001752452654
    4.523832351750659
    4.523663561220222
    4.523495378663532
    4.523327801890704
    4.523160828719743
    4.5229944569765115
    4.522828684494694
    4.522663509115791
    4.52249892868907
    4.522334941071547
    4.52217154412796
    4.522008735730736
    4.521846513759958
    4.521684876103358
    4.521523820656273
    4.521363345321613
    4.5212034480098495
    4.521044126638972
    4.520885379134481
    4.520727203429336
    4.520569597463953
    4.520412559186168
    4.52025608655119
    4.520100177521615
    4.51994483006737
    4.519790042165689
    4.519635811801097
    4.519482136965379
    4.519329015657546
    4.519176445883831
    4.519024425657636
    4.518872952999521
    4.518722025937186
    4.518571642505414
    4.518421800746086
    4.518272498708123
    4.518123734447491
    4.517975506027139
    4.517827811517001
    4.517680648993969
    4.517534016541851
    4.517387912251359
    4.517242334220096
    4.517097280552498
    4.516952749359838
    4.516808738760195
    4.516665246878423
    4.516522271846126
    4.5163798118016425
    4.516237864890021
    4.5160964292629835
    4.515955503078912
    4.515815084502823
    4.515675171706342
    4.515535762867679
    4.5153968561716065
    4.515258449809438
    4.515120541978997
    4.514983130884609
    4.514846214737052
    4.514709791753551
    4.514573860157764
    4.514438418179744
    4.514303464055911
    4.514168996029046
    4.514035012348255
    4.5139015112689425
    4.513768491052823
    4.513635949967841
    4.513503886288198
    4.513372298294308
    4.513241184272776
    4.513110542516388
    4.5129803713240655
    4.51285066900086
    4.512721433857946
    4.512592664212555
    4.512464358387999
    4.512336514713613
    4.5122091315247665
    4.512082207162818
    4.511955739975094
    4.511829728314879
    4.5117041705413925
    4.511579065019769
    4.511454410121006
    4.511330204221995
    4.511206445705468
    4.511083132959975
    4.51096026437987
    4.510837838365307
    4.5107158533221785
    4.51059430766214
    4.510473199802552
    4.510352528166486
    4.51023229118269
    4.510112487285568
    4.509993114915171
    4.509874172517161
    4.509755658542807
    4.50963757144895
    4.50951990969799
    4.509402671757868
    Iteration 1050: Cost     4.51   
    4.509285856102039
    4.509169461209462
    4.509053485564568
    4.508937927657258
    4.508822785982858
    4.508708059042124
    4.508593745341216
    4.508479843391655
    4.508366351710347
    4.508253268819524
    4.508140593246749
    4.508028323524885
    4.507916458192075
    4.507804995791743
    4.507693934872547
    4.5075832739883674
    4.507473011698308
    4.5073631465666555
    4.507253677162868
    4.507144602061552
    4.507035919842459
    4.506927629090447
    4.50681972839547
    4.5067122163525735
    4.506605091561853
    4.506498352628445
    4.506391998162514
    4.506286026779231
    4.506180437098757
    4.50607522774622
    4.505970397351695
    4.505865944550205
    4.505761867981676
    4.505658166290941
    4.505554838127714
    4.505451882146564
    4.50534929700692
    4.5052470813730245
    4.505145233913951
    4.50504375330354
    4.504942638220435
    4.504841887348026
    4.504741499374441
    4.504641472992546
    4.504541806899903
    4.5044424997987775
    4.504343550396099
    4.5042449574034595
    4.504146719537084
    4.504048835517842
    4.503951304071184
    4.5038541239271686
    4.5037572938204224
    4.503660812490135
    4.503564678680032
    4.503468891138366
    4.503373448617895
    4.503278349875874
    4.503183593674036
    4.503089178778568
    4.502995103960105
    4.502901367993708
    4.502807969658853
    4.502714907739411
    4.502622181023631
    4.502529788304132
    4.502437728377874
    4.50234600004616
    4.502254602114602
    4.502163533393121
    4.5020727926959205
    4.501982378841468
    4.501892290652506
    4.501802526956001
    4.501713086583155
    4.501623968369366
    4.5015351711542415
    4.501446693781558
    4.501358535099273
    4.501270693959467
    4.5011831692183755
    4.501095959736355
    4.501009064377853
    4.50092248201142
    4.500836211509673
    4.5007502517493
    4.500664601611016
    4.500579259979591
    4.500494225743793
    4.5004094977964115
    4.500325075034205
    4.500240956357912
    4.500157140672241
    4.500073626885831
    4.499990413911263
    4.499907500665022
    4.499824886067514
    4.499742569043017
    4.499660548519692
    4.499578823429556
    4.499497392708477
    4.499416255296161
    4.499335410136121
    4.499254856175682
    4.499174592365959
    4.499094617661846
    4.4990149310220025
    4.498935531408836
    4.498856417788498
    4.498777589130854
    4.498699044409483
    4.4986207826016615
    4.498542802688363
    4.498465103654209
    4.498387684487495
    4.49831054418015
    4.498233681727738
    4.498157096129444
    4.498080786388059
    4.498004751509955
    4.497928990505097
    4.497853502387002
    4.497778286172755
    4.497703340882971
    4.497628665541798
    4.497554259176892
    4.497480120819419
    4.497406249504034
    4.497332644268858
    4.497259304155493
    4.497186228208988
    4.49711341547782
    4.4970408650139095
    4.496968575872587
    4.496896547112577
    4.496824777795999
    4.496753266988366
    4.496682013758532
    4.4966110171787195
    4.496540276324487
    4.496469790274731
    4.496399558111664
    4.496329578920791
    4.4962598517909225
    4.496190375814155
    4.496121150085844
    4.496052173704616
    4.49598344577233
    4.495914965394089
    4.49584673167822
    Iteration 1200: Cost     4.50   
    4.495778743736256
    4.495711000682939
    4.495643501636183
    4.495576245717105
    4.495509232049967
    4.495442459762186
    4.495375927984337
    4.495309635850109
    4.495243582496324
    4.4951777670629065
    4.495112188692884
    4.4950468465323645
    4.494981739730536
    4.49491686743965
    4.49485222881501
    4.494787823014972
    4.494723649200905
    4.494659706537212
    4.494595994191309
    4.494532511333591
    4.494469257137471
    4.494406230779307
    4.4943434314384545
    4.494280858297201
    4.4942185105407875
    4.494156387357403
    4.494094487938134
    4.494032811477004
    4.493971357170925
    4.4939101242197115
    4.493849111826053
    4.493788319195519
    4.493727745536529
    4.49366739006036
    4.49360725198114
    4.49354733051581
    4.493487624884137
    4.493428134308705
    4.493368858014889
    4.493309795230865
    4.493250945187582
    4.493192307118759
    4.493133880260873
    4.493075663853159
    4.493017657137589
    4.492959859358859
    4.492902269764394
    4.492844887604319
    4.492787712131477
    4.492730742601389
    4.492673978272259
    4.492617418404968
    4.492561062263052
    4.492504909112713
    4.492448958222776
    4.492393208864719
    4.492337660312629
    4.492282311843223
    4.492227162735803
    4.492172212272291
    4.492117459737173
    4.492062904417529
    4.492008545602998
    4.491954382585781
    4.491900414660625
    4.49184664112482
    4.491793061278188
    4.491739674423073
    4.491686479864331
    4.491633476909317
    4.4915806648678895
    4.491528043052386
    4.491475610777625
    4.491423367360894
    4.491371312121932
    4.491319444382941
    4.491267763468547
    4.49121626870583
    4.49116495942427
    4.491113834955785
    4.4910628946346876
    4.491012137797683
    4.490961563783879
    4.490911171934752
    4.490860961594161
    4.4908109321083165
    4.490761082825792
    4.490711413097507
    4.490661922276715
    4.490612609719008
    4.490563474782287
    4.490514516826772
    4.490465735214987
    4.4904171293117505
    4.490368698484176
    4.490320442101644
    4.49027235953582
    4.490224450160623
    4.490176713352229
    4.490129148489065
    4.4900817549517935
    4.490034532123305
    4.4899874793887244
    4.489940596135376
    4.4898938817528
    4.489847335632735
    4.489800957169108
    4.489754745758032
    4.489708700797792
    4.48966282168884
    4.489617107833788
    4.489571558637408
    4.489526173506605
    4.489480951850421
    4.489435893080036
    4.489390996608741
    4.489346261851942
    4.48930168822716
    4.489257275153997
    4.48921302205416
    4.489168928351442
    4.48912499347169
    4.489081216842844
    4.4890375978948835
    4.48899413605986
    4.488950830771858
    4.488907681467005
    4.488864687583457
    4.488821848561393
    4.488779163843021
    4.488736632872537
    4.488694255096154
    4.488652029962077
    4.488609956920499
    4.488568035423583
    4.488526264925481
    4.488484644882306
    4.488443174752119
    4.488401853994953
    4.488360682072769
    4.488319658449471
    4.4882787825909
    4.48823805396481
    4.488197472040883
    4.4881570362906995
    4.48811674618776
    4.488076601207441
    4.4880366008270265
    4.487996744525673
    4.487957031784419
    Iteration 1350: Cost     4.49   
    4.487917462086165
    4.487878034915682
    4.487838749759594
    4.4877996061063685
    4.487760603446324
    4.48772174127161
    4.487683019076203
    4.4876444363559145
    4.487605992608355
    4.487567687332956
    4.48752952003095
    4.487491490205359
    4.487453597361009
    4.487415841004499
    4.4873782206442
    4.487340735790274
    4.487303385954625
    4.48726617065093
    4.487229089394612
    4.487192141702837
    4.487155327094519
    4.487118645090291
    4.487082095212528
    4.487045676985318
    4.487009389934455
    4.48697323358746
    4.486937207473537
    4.486901311123599
    4.486865544070243
    4.486829905847748
    4.486794395992075
    4.486759014040852
    4.486723759533376
    4.486688632010598
    4.486653631015132
    4.486618756091231
    4.486584006784801
    4.486549382643359
    4.486514883216075
    4.4864805080537415
    4.486446256708759
    4.4864121287351395
    4.486378123688517
    4.48634424112611
    4.4863104806067335
    4.486276841690803
    4.486243323940305
    4.4862099269188125
    4.486176650191464
    4.486143493324961
    4.486110455887581
    4.4860775374491455
    4.486044737581024
    4.486012055856135
    4.485979491848933
    4.485947045135408
    4.4859147152930685
    4.485882501900957
    4.485850404539627
    4.485818422791136
    4.485786556239061
    4.48575480446847
    4.485723167065915
    4.4856916436194645
    4.485660233718653
    4.485628936954484
    4.485597752919455
    4.4855666812075246
    4.485535721414106
    4.4855048731360725
    4.485474135971758
    4.4854435095209375
    4.485412993384827
    4.4853825871660735
    4.485352290468771
    4.485322102898418
    4.485292024061953
    4.485262053567723
    4.485232191025479
    4.485202436046396
    4.485172788243023
    4.485143247229333
    4.485113812620666
    4.485084484033761
    4.485055261086734
    4.4850261433990735
    4.484997130591646
    4.484968222286679
    4.4849394181077535
    4.484910717679821
    4.484882120629174
    4.484853626583452
    4.484825235171639
    4.484796946024052
    4.484768758772342
    4.484740673049485
    4.4847126884897826
    4.4846848047288494
    4.484657021403618
    4.484629338152314
    4.484601754614484
    4.484574270430968
    4.484546885243897
    4.484519598696685
    4.484492410434043
    4.484465320101953
    4.484438327347678
    4.484411431819746
    4.484384633167955
    4.484357931043358
    4.484331325098273
    4.484304814986267
    4.484278400362154
    4.484252080881994
    4.484225856203081
    4.484199725983951
    4.484173689884361
    4.484147747565297
    4.48412189868897
    4.484096142918808
    4.484070479919438
    4.484044909356718
    4.484019430897684
    4.48399404421059
    4.483968748964878
    4.483943544831182
    4.483918431481318
    4.483893408588292
    4.483868475826282
    4.483843632870647
    4.483818879397901
    4.483794215085735
    4.483769639613
    4.483745152659697
    4.483720753906989
    4.483696443037178
    4.48367221973372
    4.4836480836812
    4.4836240345653495
    4.483600072073022
    4.483576195892218
    4.4835524057120315
    4.483528701222707
    4.4835050821155855
    4.48348154808312
    4.483458098818879
    4.48343473401754
    4.483411453374868
    4.483388256587726
    w,b found by gradient descent: 1.166362350335582 -3.63029143940436


**Expected Output**:
<table>
  <tr>
    <td> <b> w, b found by gradient descent<b></td>
    <td> 1.16636235 -3.63029143940436</td> 
  </tr>
</table>

We will now use the final parameters from gradient descent to plot the linear fit. 

Recall that we can get the prediction for a single example $f(x^{(i)})= wx^{(i)}+b$. 

To calculate the predictions on the entire dataset, we can loop through all the training examples and calculate the prediction for each example. This is shown in the code block below.


```python
m = x_train.shape[0]
predicted = np.zeros(m)

for i in range(m):
    predicted[i] = w * x_train[i] + b
```

We will now plot the predicted values to see the linear fit.


```python
# Plot the linear fit
plt.plot(x_train, predicted, c = "b")

# Create a scatter plot of the data. 
plt.scatter(x_train, y_train, marker='x', c='r') 

# Set the title
plt.title("Profits vs. Population per city")
# Set the y-axis label
plt.ylabel('Profit in $10,000')
# Set the x-axis label
plt.xlabel('Population of City in 10,000s')
```




    Text(0.5, 0, 'Population of City in 10,000s')




![png](output_42_1.png)


Your final values of $w,b$ can also be used to make predictions on profits. Let's predict what the profit would be in areas of 35,000 and 70,000 people. 

- The model takes in population of a city in 10,000s as input. 

- Therefore, 35,000 people can be translated into an input to the model as `np.array([3.5])`

- Similarly, 70,000 people can be translated into an input to the model as `np.array([7.])`



```python
predict1 = 3.5 * w + b
print('For population = 35,000, we predict a profit of $%.2f' % (predict1*10000))

predict2 = 7.0 * w + b
print('For population = 70,000, we predict a profit of $%.2f' % (predict2*10000))
```

    For population = 35,000, we predict a profit of $4519.77
    For population = 70,000, we predict a profit of $45342.45


**Expected Output**:
<table>
  <tr>
    <td> <b> For population = 35,000, we predict a profit of<b></td>
    <td> $4519.77 </td> 
  </tr>
  
  <tr>
    <td> <b> For population = 70,000, we predict a profit of<b></td>
    <td> $45342.45 </td> 
  </tr>
</table>
